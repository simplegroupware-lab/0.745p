<?php
	/**************************************************************************\
	* Simple Groupware 0.746                                                   *
	* Adapted by Patrick Pliessnig                                             *
	\**************************************************************************/
 
  define("MAIN_SCRIPT",basename($_SERVER["PHP_SELF"]));
  header("Content-Type: text/html; charset=utf-8");
  error_reporting(E_ALL);
  
  
  // instantiate sgs
  require('core/sgs.php');
  $sgs = new \sgs\core\sgs( $storeDir = '../simple_store', $coreVersionToConfigure='0_745');

  // boot sgs
  try { $sgs->boot();} catch (Exception $e) {exit;}  

  // process request
  $sgs->processSession();

  