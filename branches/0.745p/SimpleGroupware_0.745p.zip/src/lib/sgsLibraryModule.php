<?php declare(strict_types=1);


namespace sgs\library;
use sgs\core\library\ModuleAbstract as ModuleAbstract;

class sgsLibraryModule {
	use ModuleAbstract;

	protected static function register_autoload($class) {

		// IMAP Service
		if ($class=='Net_IMAP') {
			require('lib/mail/IMAP.php');

		// SMTP Service
		} else if ($class=='Net_SMTP') {
			require('lib/mail/SMTP.php');

		// PEAR Service
		} else if ($class=='PEAR' or $class=='PEAR_Error') {
			require('lib/pear/PEAR.php');

		// Template Service
		} else if ($class=='Smarty') {
			require("lib/smarty/Smarty.class.php");

		}
	}

}