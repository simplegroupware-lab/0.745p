<?php declare(strict_types=1);

	/**************************************************************************\
	\**************************************************************************/

namespace sgs\core;
use sgs\core\library\{
	sgsStore,
	sgsConfig
};

class sgs {
	
	private static sgsCore $core;
	private static sgsStore $store;
	private static sgsConfig $config;
	
	public function __construct(string $storeDir, string $coreVersionToConfigure) {
		require('core/sgsCore.php');
		self::$core = new sgsCore(self::noContent());
		self::$core->loadKernel();
		self::$store = new sgsStore($storeDir);
		self::$config = new sgsConfig(self::$store,$coreVersionToConfigure);
	}

	public function boot() {

		try {
			self::$core->configure($withConfig = self::$config);
		} catch (Exception $e) {throw $e;}
		
		self::$core->ignoreUserAbortOnHTTPPost();
		self::$core->useHTTPSOnForceSSL();
		self::$core->removePathInfoFromUrl();

		// delay on suspected dos attack
		self::$core->delayOnDOS();

		// load functions.php
		self::$core->loadFunctions();

		// load core modules
		self::$core->loadModules();

		self::$core->setBufferOnContent();
		self::$core->setErrorHandler($default='debug_handler');
		self::$core->setServerAddress($default='127.0.0.1');
		self::$core->setUserAgent($default='mozilla/5 rv:1.4');
		self::$core->setWebServer($default='Apache');

		try {
			self::$core->checkBrowserCompatibilityOnContent();
		} catch (Exception $e) {
			sys_die($e->getMessage());
		}

		try {
			self::$core->checkSetupLanguage();
		} catch (Exception $e) {
			sys_die($e->getMessage());
		}
		
		self::$core->initSystem();
	}

	public function processSession() {
		self::$core->processSessionOnContent();
		self::$core->outputBufferOnContent();
	}	

	public function core(): sgsCore {
		return self::$core;
	}

	public function store(): sgsStore {
		return self::$store;
	}

	public function config(): sgsConfig {
		return self::$config;
	}

	public static function setNoContent() {
		if (!defined('NOCONTENT')) define('NOCONTENT',true);
	}
	
	private static function noContent(): bool {
		return (defined('NOCONTENT') and NOCONTENT);
	}
}