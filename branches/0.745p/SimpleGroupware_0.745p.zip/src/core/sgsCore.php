<?php declare(strict_types=1);

	/**************************************************************************\
	\**************************************************************************/

namespace sgs\core;
use sgs\core\library\{
	sgsRequest,
	sgsSession,
	sgsApp
};


class sgsCore {
	
	private library\sgsConfig $config;
	private bool $noContent;
	
	public function __construct(bool $noContent) {
		$this->noContent = $noContent;
	}


	public function loadKernel() {
		require('library/ModuleAbstract.php');
		require('library/sgsCoreLibraryModule.php');
		library\sgsCoreLibraryModule::setup();
	}

	// verify config and setup again if necessary
	public function configure(library\sgsConfig $withConfig) {
		$this->config=$withConfig;
		try { 
			$this->config->load();
		} catch (\Exception $e) {
			switch ($e->getCode()) {
				case 2:
					// wrong config version found
					$this->config->backup();
					break;
				case 1:
					// no version found
					$this->config->setup();
					break;
			}			
			throw $e;
		}
		
		if (!$this->config->isDBConfigured()) throw new \Exception('no DB',3);
	}

	// load global functions
	public function loadFunctions() {
		require("core/functions.php");
	}

	// load all modules that sgs depends on
	public function loadModules() {		

		require('types/sgsCoreTypesModule.php');
		types\sgsCoreTypesModule::setup();

		// load sgs-modules
		require('modules/sgsModulesModule.php');
		\sgs\modules\sgsModulesModule::setup();

		// load third party libraries
		require('lib/sgsLibraryModule.php');
		\sgs\library\sgsLibraryModule::setup();

		// last: load sgs core classes
		// to load remaining symbols in the global namespace
		require('classes/sgsCoreClassesModule.php');
		classes\sgsCoreClassesModule::setup();
	}

	public function ignoreUserAbort() {
		@ignore_user_abort(true);
	}
	
	public function ignoreUserAbortOnHTTPPost() {
		if (!empty($_POST)) $this->ignoreUserAbort();
	}

	public function useHTTPSOnForceSSL() {
		if ($this->config->isForceSSL() and (!isset($_SERVER["HTTPS"]) or $_SERVER["HTTPS"]!="on")) {
			header("Location: https://".$_SERVER["HTTP_HOST"].$_SERVER["SCRIPT_NAME"]."?".$_SERVER["QUERY_STRING"]);
			exit;
		}
	}
	
	public function removePathInfoFromUrl() {
		if (!empty($_SERVER["PATH_INFO"]) and $_SERVER["PATH_INFO"]!=$_SERVER["SCRIPT_NAME"] and !strpos($_SERVER["PATH_INFO"],".exe")) {
			header("Location: http://".$_SERVER["HTTP_HOST"].$_SERVER["SCRIPT_NAME"]);
			exit;
		}	
	}

	// whether content is produced or not
	public function isNoContent(): bool {
		return $this->noContent;
	}

	// whether content is produced or not
	public function isWithContent(): bool {
		return !$this->isNoContent();
	}

	
	// prevent denial of service
	public function delayOnDOS() {
		
		if ($this->config->isCheckDOS() and !$this->config->isSetupAuthNTLMSSO() and !$this->config->isDebug()) return;

		if ($this->isNoContent() or !empty($_SERVER["HTTP_X_MOZ"])) return;

		if (isset($_SERVER["HTTP_CLIENT_IP"])) $ip = $_SERVER["HTTP_CLIENT_IP"];
		else if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		else if (isset($_SERVER["REMOTE_ADDR"])) $ip = $_SERVER["REMOTE_ADDR"];
		else $ip = "0.0.0.0";

		$delay = false;
		$ip = filter_var($ip, FILTER_VALIDATE_IP);
		if (APC) {
			if (($val = apc_fetch("dos".$ip))===false) $val=0;
			apc_store("dos".$ip, ++$val, 1);
			if ($val>2) $delay = true;
		} else {
			$ip_file = SIMPLE_CACHE."/ip/".str_replace(array(".",":"),"-",$ip);
			if (@file_exists($ip_file) and time()-@filemtime($ip_file)<1) {
				if (file_exists($ip_file."_2") and time()-filemtime($ip_file."_2")<1) $delay = true;
				touch($ip_file."_2");
			}
			touch($ip_file);
		}

		if ($delay) {
			if (empty($_SERVER["HTTP_ACCEPT_LANGUAGE"])) { // client
				header("HTTP/1.0 408 Request timeout");
			} else {
				echo "<html><body><script>setTimeout('document.location.reload()',1500);</script>Please wait ...<noscript>Please hit reload.</noscript></body></html>"; 
			}
			exit;
		}
	}

	// activates buffer
	public function setBufferOnContent() {
		if ($this->isWithContent()) ob_start();
	}

	// output buffer
	public function outputBufferOnContent() {
		if ($this->isWithContent()) {
			$output = $this->getContent();
			if (!empty(\sys::$alert) or trim($output)!="") \sys_message_box("Error:",$output.implode("\n",\sys::$alert));
			\sys_process_output();
		}
	}

	// deactivates and returns ob buffer
	private function getContent() {
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}
	
	public function setErrorHandler($default='debug_handler') {
		set_error_handler($default);
	}
	
	public function setServerAddress($default='127.0.0.1') {
		if (!isset($_SERVER["SERVER_ADDR"]) or $_SERVER["SERVER_ADDR"]=="") $_SERVER["SERVER_ADDR"]=$default;
	}
	
	public function setUserAgent($default='mozilla/5 rv:1.4') {
		if (!isset($_SERVER["HTTP_USER_AGENT"])) $_SERVER["HTTP_USER_AGENT"]=$default;
	}
	
	public function setWebServer($default='Apache') {
		  if (!isset($_SERVER["SERVER_SOFTWARE"])) $_SERVER["SERVER_SOFTWARE"]=$default;
	}
	
	// throws exception if browser is not compatible
	public function checkBrowserCompatibilityOnContent() {
		if (!$this->isNoContent() and !login_browser_detect() and !DEBUG and empty($_REQUEST["export"])) {
			throw new \Exception('Browser not supported: '.\sys::$browser['str'],\login::browser_detect_toString());
		} 
	}

	// throws exception if wrong setup_language
	public function checkSetupLanguage() {
		if (!$this->config->isDebug() and $this->config->getSetupLanguage()!="{t}en{/t}") {
			throw new \Exception(sprintf('Program is installed with language %s, please use a different url or run the setup again.',$this->config->getSetupLanguage()));
		}
	}


	public function initSystem() {
		\sys::init();
	}

	// TODO needs structure
	public function processSessionOnContent() {
		
		$request = new sgsRequest;
		$session = new sgsSession($request);
		$app	 = new sgsApp($state = $session->appState());
		
		if ($this->isWithContent()) {

			$session->process();
			
			// moved to $session->process()
			// \folder_process_session_request();
			
			folder_build_folders();
			$GLOBALS["table"] = \db_get_schema($GLOBALS["schemafile"],$GLOBALS["tfolder"],$GLOBALS["tview"],true,!empty($_REQUEST["popup"]));
			$GLOBALS["tname"] = $GLOBALS["table"]["att"]["NAME"];

			if (!empty($GLOBALS["table"]["att"]["LOAD_LIBRARY"])) require($GLOBALS["table"]["att"]["LOAD_LIBRARY"]);

			\sys_process_session_request();

			if (!empty($GLOBALS["current_view"]["ENABLE_CALENDAR"])) {
				\date::process_session_request();
				$session = $_SESSION[ $GLOBALS["tname"] ][ "_".$GLOBALS["tfolder"] ];
				\date::build_datebox($session["today"], $session["markdate"], $session["weekstart"]);
			}
			\asset_process_session_request();

			if (!empty($GLOBALS["current_view"]["ENABLE_CALENDAR"]) and (empty($_REQUEST["iframe"]) or $_REQUEST["iframe"]=="2")) {
				\date::build_views();
			}
		}

//		$output = $this->getContent();
//		if (!empty(\sys::$alert) or trim($output)!="") \sys_message_box("Error:",$output.implode("\n",\sys::$alert));
//		\sys_process_output();
	}
	
}