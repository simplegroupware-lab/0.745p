<?php declare(strict_types=1);

namespace sgs\core\library\request\query;
use sgs\core\library\request\query;

final class fschema extends query {
	public function process() {
		if ($this->exists()) {
			$row = db_select_first("simple_sys_tree","id",array("ftype=@ftype@",$_SESSION["permission_sql_read"]),"lft asc",array("ftype"=>str_replace("simple_","",$this->value)));

			if (!isset($row["id"])) {
			sys_warning("Item not found. (".$this->value.")");
			} else $this->request->folder = $row["id"];
		}
	}
}