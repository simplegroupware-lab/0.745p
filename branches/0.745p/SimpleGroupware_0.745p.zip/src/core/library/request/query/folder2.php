<?php declare(strict_types=1);

namespace sgs\core\library\request\query;
use sgs\core\library\request\query;

final class folder2 extends query {

	public function process() {
		$view	= $this->request->view;
		$view2	= $this->request->view2;
		$folder	= $this->request->folder;
		
		if (!is_null($this->value) and !is_null($view2->value) and is_null($folder->value)) {
			if (!isset($folder)) $folder = $this->value;
			if (!isset($view)) $view = $view2->value;
		}
	}
}