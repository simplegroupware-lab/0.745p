<?php declare(strict_types=1);

namespace sgs\core\library\request\query;
use sgs\core\library\request\query;

final class view2 extends query {}