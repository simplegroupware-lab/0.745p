<?php declare(strict_types=1);

namespace sgs\core\library;

// autoload namespace sgs\core\library
// in directory ./core/library
class sgsCoreLibraryModule {
	use ModuleAbstract;

	// load the file of a fully specified class 'sgs\core\library\subdir1\subdir2\myClass'
	// the file should be 'core/library/subdir1/subdir2/myClass.php'
	private static function register_autoload($class) {
		if (self::strbegins($class, __NAMESPACE__ )) {
			require(substr(str_replace('\\', '/', $class),4).'.php');
		}
	}

}