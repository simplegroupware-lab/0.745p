<?php declare(strict_types=1);


namespace sgs\core\library;
use sgs\core\library\db\sql as dbServer;
use sgs\core\library\v0745\sql\server as sqlServer;
use sgs\core\library\v0745\sql\engines\{mysql,pgsql,sqlite};
use Exception;


// sgs database, handels input, output to the database
class sgsDB {

	// TODO implement decent engine factory
	private const engineNamespace = 'sgs\\core\\library\\v0745\\sql\\engines\\';

	private string $host;
	private string $user;
	private string $password;
	private string $name;
	
	// set to private
	public dbServer $dbServer;
	
	public function __construct(
			string $type,
			string $host,
			string $user,
			string $password,
			string $name) {

		// engineType might be mysql, pgsql or sglite (only mysql is tested)
		$engine		= self::engineNamespace.$type;
		$engine		= new $engine();
		$sqlServer	= new sqlServer($engine);
		$this->dbServer = $sqlServer;
		
		$this->host		= $host;
		$this->user		= $user;
		$this->password = $password;
		$this->name		= $name;
	}

	public function connect() {
		// TODO: eliminate sql_connect from functions.php
		$success = $this->dbServer->connect(
			$this->host,
			$this->user,
			$this->password,
			$this->name
		);
		if (!$success) {
			throw new Exception(
				sprintf(
					"{t}Cannot connect to database %s on %s.{/t}\n",
					$this->name,
					$this->host
				).$this->dbServer->error()
			);
		}
	}

	// remove
	public function connect_old(): bool {
		$success = sql_connect(
			$this->host,
			$this->user,
			$this->password,
			$this->name
		);
		return $success;
	}
	
	public function isConfigured(): bool {
		return isset($this->host);
	}

}