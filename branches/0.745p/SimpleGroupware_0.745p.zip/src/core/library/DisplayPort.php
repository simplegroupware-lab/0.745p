<?php declare(strict_types=1);
	/**************************************************************************\
	* ioc.systems 0.745p                                                       *
	* https://ioc.systems                                                      *
	* Copyright (C) 2020 by Patrick Pliessnig                                  *
	* GNU General Public License Version 2 WITHOUT ANY WARRANTY                *
	\**************************************************************************/

/**
 * abstraction for a template engine
 */

namespace sgs\core\library;

interface DisplayPort {

	

}