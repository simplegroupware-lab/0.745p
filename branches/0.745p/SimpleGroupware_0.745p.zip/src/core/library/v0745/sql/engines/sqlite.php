<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql\engines;

class sqlite extends engineAbstract {
	
	private $connection_error = null;

	public function connect (string $server, string $username, string $password, string $database='') {
		try {
			$link = new PDO('sqlite:'.SIMPLE_STORE.'/sqlite3_'.urlencode($database).'.db','','',array(PDO::ATTR_PERSISTENT=>false));
			$link->sqliteCreateFunction('REGEXP_LIKE', '_sql_sqlite_match', 2);
			$this->connection = $link;
		}
		catch(Exception $e) {
			$this->connection = $e->getMessage();
			return false;
		}
		if (!defined('NOSESSION')) register_shutdown_function('_sql_sqlite_shutdown');
		$this->isConnected = true;
		return $this->isConnected;
	}

	public function query(string $sql) {
		return $this->connection->query($sql);
	}

	public function error(): string {
		if (!empty($this->connection)) return implode(' ',$this->connection->errorInfo());
		return $this->$connection_error;
		return '';
	}

}