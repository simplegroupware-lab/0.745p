<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql;

class functions {


}