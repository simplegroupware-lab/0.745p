<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql\engines;

class mysql extends engineAbstract {

	public function connect (string $server, string $username, string $password, string $database='') {
		if (!$link = mysqli_connect('p:' . $server,$username,$password)) return false;
		if ($database!='' and !mysqli_select_db($link,$database)) return false;
		$this->connection = $link;
		if (!mysqli_query($link, "set names 'utf8', sql_mode = ''")) return false;
		return true;
	}

	public function query(string $sql) {
		return mysqli_query($this->connection, $sql);
	}

	public function error(): string {
		if (!empty($this->connection)) return mysqli_errno($this->connection).' '.mysqli_error($this->connection);
		return mysqli_errno().' '.mysqli_error();
		return '';
	}

}