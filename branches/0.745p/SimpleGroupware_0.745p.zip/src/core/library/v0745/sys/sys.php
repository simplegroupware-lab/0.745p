<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sys;

class sys {
	
	public function get_db() { return \sys::$db; }
	public function set_db($link) { \sys::$db = $link; }

	public function get_db_error() { return \sys::$db_error; }
	public function set_db_error($error) { \sys::$db_error = $error; }

}