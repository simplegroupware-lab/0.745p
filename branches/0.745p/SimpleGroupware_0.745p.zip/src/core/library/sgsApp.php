<?php declare(strict_types=1);

/**
 * main sgs application
 */

namespace sgs\core\library;
use sgs\core\library\app\state\app as AppState;
use sgs\core\library\session\state\folders;

class sgsApp {
		
	private AppState $state;
	private folders $folders;
	
	public function __construct(AppState $state) {
		$this->state = $state;
		$this->folders = new folders($this->state->foldersState());
		
	}
	
	public function build() {
		$this->folders->build();
	}
	
}