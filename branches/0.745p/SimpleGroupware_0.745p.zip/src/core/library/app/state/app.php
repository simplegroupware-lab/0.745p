<?php declare(strict_types=1);

/**
 * fddghh
 */

namespace sgs\core\library\app\state;
use sgs\core\library\app\state\{folders,view};

interface app {
	
	const treetype		= 'treetype';
	const treevisible	= 'treevisible';
	const hidedata		= 'hidedata';

	public function foldersState(): folders;
	public function viewState(): view;
}