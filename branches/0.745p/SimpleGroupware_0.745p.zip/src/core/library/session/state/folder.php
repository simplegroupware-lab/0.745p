<?php declare(strict_types=1);

namespace sgs\core\library\session\state;
use sgs\core\library\app\state\folder as folderState;

class folder extends repository implements folderState {


}