<?php declare(strict_types=1);


namespace sgs\core\library;

trait ModuleAbstract{
	
	private function __construct() {}

	public static function setup() {
		spl_autoload_register(__CLASS__ . '::register_autoload');
	}

	private static function strbegins($haystick, $needle) {
		if (strncmp($haystick,$needle,strlen($needle))==0) return true;
		return false;
	}
}