<?php declare(strict_types=1);

/**
 * url request
 */

namespace sgs\core\library;

class sgsFolder {


	public function find () {

	}
	
}