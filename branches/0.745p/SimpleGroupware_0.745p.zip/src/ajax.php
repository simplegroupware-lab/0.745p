<?php
	/**************************************************************************\
	* Simple Groupware 0.746                                                   *
	* Adapted by Patrick Pliessnig                                             *
	\**************************************************************************/

define("MAIN_SCRIPT",basename($_SERVER["PHP_SELF"]));
define("NOCONTENT",true);
header("Content-Type: application/json; charset=utf-8");
error_reporting(E_ALL);


// instantiate sgs
require('core/sgs.php');
$sgs = new \sgs\core\sgs( $storeDir = '../simple_store', $coreVersionToConfigure='0_745');

$sgs->core()->configure($withConfig = $sgs->config());

if (!$sgs->config()->isDBConfigured()) exit;
$sgs->core()->loadFunctions();
$sgs->core()->loadModules();
$sgs->core()->setErrorHandler($default='debug_handler');
$sgs->core()->ignoreUserAbort();

try {
	$sgs->config()->db()->connect();
} catch (Exception $e) {
	trigger_error($e->getMessage(),E_USER_ERROR);
	exit($e->getMessage());
}



$save_session = false;
if (ini_get("suhosin.session.encrypt")) $save_session = true; // workaround for broken session_encode()
login_handle_login($save_session);

$class = "ajax";
if (!empty($_REQUEST["class"]) and strpos($_REQUEST["class"],"_ajax")) $class = $_REQUEST["class"];

if (empty($_REQUEST["function"]) and empty($_SERVER["HTTP_SOAPACTION"])) {
  $reflect = new ReflectionClass($class); 
  $output = "";
  foreach($reflect->getMethods(ReflectionMethod::IS_PUBLIC) as $reflectmethod) {
	$output .= $reflectmethod->getDocComment()."\n";
    $output .= "{$reflectmethod->getName()}(";
    foreach($reflectmethod->getParameters() as $num => $param) {
		if ($param->isArray()) $output .= " array";
		$output .= " \$".$param->getName();
		if ($param->isDefaultValueAvailable()) $output .= "=".str_replace("\n","",var_export($param->getDefaultValue(),true));
        if ($reflectmethod->getNumberOfParameters() != $num+1) $output .= ",";
    }
	$output .= " )\n\n";
  }
  sys_die("Simple Groupware Soap/Ajax Functions","<pre>".$output."</pre>");
}

if (!empty($_SERVER["HTTP_SOAPACTION"])) {
  if (!extension_loaded("soap")) sys_die(sprintf("{t}%s is not compiled / loaded into PHP.{/t}","Soap"));
  $soap = new SoapServer(null, array('uri'=>'sgs'));
  $soap->setClass($class);
  $soap->handle();

} else if ($_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest") {
  $func = $_REQUEST["function"];
  if ($func=="type_pmwikiarea::ajax_render_preview") require("lib/pmwiki/pmwiki.php");
  if (!function_exists("json_encode")) require("lib/json/JSON.php");

  if ((strpos($func,"_ajax::") or strpos($func,"::ajax_")) and substr_count($func,"::")==1) {
    list($class,$func) = explode("::",$func);
  }
  ajax::require_method($func, $class);
  
  if (!empty($_REQUEST["params"])) {
    $params = json_decode($_REQUEST["params"], true);
  } else {
    $params = json_decode(file_get_contents("php://input"),true);
  }
  echo json_encode(call_user_func_array(array($class, $func), $params));

  if (!empty($_SESSION["notification"]) or !empty($_SESSION["warning"])) ajax::session_save();
}