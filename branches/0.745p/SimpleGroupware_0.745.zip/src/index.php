<?php
	/**************************************************************************\
	* Simple Groupware 0.746                                                   *
	* Adapted by Patrick Pliessnig                                             *
	\**************************************************************************/
 
  define("MAIN_SCRIPT",basename($_SERVER["PHP_SELF"]));
  header("Content-Type: text/html; charset=utf-8");
  error_reporting(E_ALL);
  
  // 'register_globals' is removed by PHP 5.4.0
  // this code is candidate for removal
  // unregister_globals();

  
  // instantiate sgs
  require('core/sgs.php');
  $sgs = new \sgs\core\sgs( $storeDir = '../simple_store', $coreVersionToConfigure='0_745');

  // boot sgs
  try { $sgs->boot();} catch (Exception $e) {exit;}  

  // process request
  $sgs->processSession();

  
  // 'register_globals' is removed by PHP 5.4.0
  // this code is candidate for removal
  function unregister_globals() {
	if (ini_get("register_globals")) {
		$valid = array("GLOBALS","_REQUEST", "_FILES","_SERVER","_COOKIE","_GET","_POST","browser");
		foreach (array_keys($GLOBALS) as $key) if (!in_array($key,$valid)) unset($GLOBALS[$key]);
	}
  }
