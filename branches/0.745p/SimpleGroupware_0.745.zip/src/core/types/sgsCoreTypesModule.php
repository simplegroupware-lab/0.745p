<?php declare(strict_types=1);


namespace sgs\core\types;
use sgs\core\library\ModuleAbstract as ModuleAbstract;

class sgsCoreTypesModule{
	use ModuleAbstract;
	

	private static function register_autoload($class) {
		if (\sys_strbegins($class,'type_')) {
			require(\sys_custom('core/types/'.basename(substr($class,5)).'.php'));
		}
	}

}