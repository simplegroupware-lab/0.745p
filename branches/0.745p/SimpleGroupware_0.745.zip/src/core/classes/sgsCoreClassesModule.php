<?php declare(strict_types=1);


namespace sgs\core\classes;
use sgs\core\library\ModuleAbstract as ModuleAbstract;

class sgsCoreClassesModule {
	use ModuleAbstract;

	protected static function register_autoload($class) {
		require(\sys_custom('core/classes/'.basename($class).'.php'));
	}

}