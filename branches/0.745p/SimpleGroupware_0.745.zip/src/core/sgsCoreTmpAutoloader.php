<?php
	/**************************************************************************\
	* temporary workaraound to load classes in case the new version            *
	* of the autoloader cannot be used. it is simply a                         *
	* replacement of the old autoloader in functions.php                       *
	* usage:                                                                   *
	* require("core/sgsCoreTmpAutoloader.php");                                *                 
	* sgsCoreTmpAutoloader::setup();                                           *
	* just after a require("core/functions.php"); statement                    *
	\**************************************************************************/

if (!defined("MAIN_SCRIPT")) exit;

class sgsCoreTmpAutoloader {

	// static class, no instance is allowed
	private function __construct(){}
	
	public static function setup() {		
		// replacement of the autoload function in functions.php
		spl_autoload_register(
			function ($class) {
				if ($class=="Net_IMAP") {
					require("lib/mail/IMAP.php");

				} else if ($class=="Net_SMTP") {
					require("lib/mail/SMTP.php");

				} else if ($class=="PEAR" or $class=="PEAR_Error") {
					require("lib/pear/PEAR.php");

				} else if (self::strbegins($class,"lib_")) {
					require("modules/lib/".basename(substr($class,4)).".php");

				} else if (self::strbegins($class,"type_")) {
					require(self::custom("core/types/".basename(substr($class,5)).".php"));

				} else {
					require(self::custom("core/classes/".basename($class).".php"));
				}
			}
		);
	}
	
	private static function custom($file) {
		if (file_exists(SIMPLE_CUSTOM.$file)) return SIMPLE_CUSTOM.$file;
		if (file_exists(SIMPLE_EXT.$file)) return SIMPLE_EXT.$file;
		return $file;
	}

	private static function strbegins($haystick, $needle) {
		if (strncmp($haystick,$needle,strlen($needle))==0) return true;
		return false;
	}

}
