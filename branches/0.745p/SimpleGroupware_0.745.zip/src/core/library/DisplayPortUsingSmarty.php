<?php declare(strict_types=1);

	/**************************************************************************\
	* ioc.systems 0.745p                                                        *
	* https://ioc.systems                                                      *
	* Copyright (C) 2020 by Patrick Pliessnig                                  *
	* GNU General Public License Version 2 WITHOUT ANY WARRANTY                *
	\**************************************************************************/

namespace sgs\core\library;

class DisplayPortUsingSmarty implements DisplayPort {

	// Smarty instance
	private $smarty;
	
	const COMPILE_DIR = "smarty";
	const TEMPLATE_DIR = "templates";
	const TEMPLATE_HELPER_DIR = "templates/helper";
	const CONFIG_DIR = "templates";


	public function __construct(\Smarty $newSmarty) {
        // TODO check if $new is a valid Smarty instance
		$this->smarty = $newSmarty;

        // in debug mode, refresh template cache automatically on change
        if (DEBUG) $this->debug_check_tpl();

		$this->setup();
	}

    public function getTemplateEngine() {return $this->smarty;}

    private function setup() {
	    $this->smarty->register_prefilter(array("modify","urladdon_quote"));
	    if (isset($_REQUEST["print"])) $this->smarty->register_outputfilter(array("modify","striplinksforms"));
	    if (isset($_REQUEST["print"])) $this->smarty->assign("print",$_REQUEST["print"]);
	    $this->smarty->compile_dir = SIMPLE_CACHE."/".self::COMPILE_DIR;
	    $this->smarty->template_dir = self::TEMPLATE_DIR;
	    $this->smarty->config_dir = self::CONFIG_DIR;
	    $this->smarty->compile_check = false;
	}

    // refresh template cache if changed
    private function debug_check_tpl() {
        $lastmod = filemtime(SIMPLE_CACHE."/".self::COMPILE_DIR);
        $folders = array(
		    self::TEMPLATE_DIR."/",
			self::TEMPLATE_HELPER_DIR."/",
			SIMPLE_CUSTOM.self::TEMPLATE_DIR."/",
			SIMPLE_CUSTOM.self::TEMPLATE_HELPER_DIR."/"
		);

        foreach ($folders as $folder) {
            if (!is_dir($folder)) continue;

            foreach (scandir($folder) as $file) {
                if ($file[0]==".") continue;

	            if (filemtime($folder.$file)>$lastmod or filemtime($folder)>$lastmod) {
					// TODO decouple from sys
	                \sys::dirs_create_empty_dir(SIMPLE_CACHE."/".self::COMPILE_DIR);
	                break;
                }
		    }
		}
    }

}