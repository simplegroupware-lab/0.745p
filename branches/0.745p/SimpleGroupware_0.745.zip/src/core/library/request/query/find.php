<?php declare(strict_types=1);

namespace sgs\core\library\request\query;
use sgs\core\library\request\query;
use sgs\core\library\sgsRequest;

final class find extends query {


	public function process() {
		if (!is_null($this->value)) {
			unset($this->request->item);
			unset($this->request->folders);

			$result = folder_process_session_find($this->values);
			$_REQUEST = array_merge($_REQUEST, $result);
			if (empty($result) and is_null($this->request->iframe->value)) {
				$params = implode(", ", $this->values);
				$params = str_replace(array("|", utf8_encode("¦"), "¦", "~"),array(", ", "", "", " like "), $params);
				sys_warning("Item not found. Parameters: ".$params, true);
			}
		}
	}
}