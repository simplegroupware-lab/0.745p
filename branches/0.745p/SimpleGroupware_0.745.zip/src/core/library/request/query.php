<?php declare(strict_types=1);

namespace sgs\core\library\request;
use sgs\core\library\sgsRequest;

abstract class query {
	
	const find			= 'find';
	const item			= 'item';
	const folders		= 'folders';
	const fschema		= 'fschema';
	const folder		= 'folder';
	const folder2		= 'folder2';
	const treetype		= 'treetype';
	const tree			= 'tree';
	const onecategory	= 'onecategory';
	const hidedata		= 'hidedata';
	const view			= 'view';
	const view2			= 'view2';
	
	protected string $key;
	protected const separator=',';
	protected sgsRequest $request;
	
	final public function __construct(sgsRequest $request) {
		$this->request = $request;
		$this->key = (new \ReflectionClass($this))->getShortName();
	}

	final public function __isset($name): bool {
		return $this->exists();
	}

	final public function __unset($name): void {
		unset($_REQUEST[$this->key]);
	}

	final public function __toString(): string {
		$value = $this->value();
		if (is_null($value)) $value = $this->values(); 
		if (is_null($value)) $value = '';
		return $this->key.'='.$value;
	}

	final public function __get(string $name ) {
		$result;
		switch ($name) {
			case 'key':
				$result=$this->key;
				break;
			case 'value':
				//query value as a string
				$result = empty($_REQUEST[$this->key])? null : $this->value();
				break;
			case 'values':
				$result = empty($_REQUEST[$this->key])? null : $this->values();
				break;
			default:
				throw new Exception('Query property does not exist.');
		}
		return $result;
	}

	final public function __set(string $key, $value): void {
		$_REQUEST[$key] = $value;
	}

	protected function exists(): bool {
		return isset($_REQUEST[$this->key]);
	}

	// returns query value as a string
	protected function value(): ?string {
		$value = null;
		if ($this->exists()) {
			$value = $_REQUEST[$this->key];
			if (is_array($value)) $value=implode(self::separator, $value);
		}
		return $value;
	}

	// returns query value(s) as an array
	protected function values(): ?array {
		$values = null;
		if ($this->exists()) {
			$values = $_REQUEST[$this->key];
			if (is_string($values)) $values=array($values);
		}
		return $values;
	}
	
}