<?php declare(strict_types=1);

/**
 * 
 */

namespace sgs\core\library\app;
use sgs\core\library\app\state\folders as state;

class folders {
	
	private state $state;
	private $tfolder;
	private $view;
	private $sel_folder;
	
	public function __construct(state $state) {
		$this->state = $state;
		$this->setup();
	}

	public function setView(view $view) {
		$this->view = $view;
		$this->view->setFolder($this->tfolder);
	}
	
	public function build() {
		
	}

	private function setup() {
		// if (empty($_SESSION["folder"])) $tfolder = 1; else $tfolder = $_SESSION["folder"];
		is_null($this->state->folder)? $this->tfolder = 1 : $this->tfolder = $this->state->folder;
	}

}