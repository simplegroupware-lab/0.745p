<?php declare(strict_types=1);

/**
 * 
 */

namespace sgs\core\library\app;
use sgs\core\library\app\state\view as state;

class view {
	
	private state $state;
	private $tview = 'none';
	
	public __construct(state $state) {
		$this->state = $state;
	}

	public function setFolder($folder) {
		$viewFolder = $this->state->view["_".$tfolder];
		if (!empty($$viewFolder)) $view = $view_folder;
	}

}