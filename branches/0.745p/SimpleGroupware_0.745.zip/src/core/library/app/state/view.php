<?php declare(strict_types=1);

/**
 * 
 */

namespace sgs\core\library\app\state;

interface view {
	const view		= 'view';
}