<?php declare(strict_types=1);

/**
 * 
 */

namespace sgs\core\library\app\state;

interface tree {
	const treetype		= 'treetype';
}