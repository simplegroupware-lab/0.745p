<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql;

interface engine {

	public function connect(string $server, string $username, string $password, string $database='');
	public function query(string $sql);
	public function error(): string;

}