<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql\engines;
use sgs\core\library\v0745\sql\engine;

abstract class engineAbstract implements engine {
	
	protected $connection = null;

	final public function connection() {
		return $this->connection;
	}
	
}