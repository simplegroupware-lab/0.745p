<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql\engines;

class pgsql extends engineAbstract {
	
	public function connect (string $server, string $username, string $password, string $database='') {
		$conn = "host='".addslashes($server)."' user='".addslashes($username)."' password='".addslashes($password)."'";
		if ($database!='') $conn .= " dbname='".addslashes($database)."'";
		if (!$link = pg_pconnect($conn)) return;
		$this->connection = $link;
		return true;
	}

	public function query(string $sql) {
		return @pg_query($this->connection,$sql);
	}

	public function error(): string {
		if (!empty($this->connection)) return pg_last_error($this->connection);
		return @pg_last_error();
		return '';
	}

}