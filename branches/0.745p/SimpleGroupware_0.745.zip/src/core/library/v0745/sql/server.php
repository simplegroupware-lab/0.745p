<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sql;
use sgs\core\library\db\sql as sqlServer;
use \sgs\core\library\v0745\sys\{sys,functions};

class server implements sqlServer {

	private engine $engine;
	private sys $sys;
	private functions $functions;

	public function __construct(engine $engine) {
		$this->engine = $engine;
		$this->sys = new sys;
		$this->functions = new functions;
	}

	public function connect(string $server, string $username, string $password, string $database="") {
		$result = $this->engine->connect($server, $username, $password, $database);
		$this->sys->set_db($this->engine->connection());
		return $result;
	}

	public function query(string $sql) {
		if ($sql=='') return true;
		if (DEBUG_SQL and !$this->functions->strbegins($sql,'select ') and !strpos($sql,'simple_sys_stats')) debug_sql('INFO '.$sql,'');
		return $this->engine->query($sql);
	}

	public function error(): string {
		return $this->engine->error();
	}

}