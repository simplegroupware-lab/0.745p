<?php declare(strict_types=1);

namespace sgs\core\library\v0745\sys;

class functions {

	public function strbegins($haystick, $needle): bool {
		return sys_strbegins($haystick, $needle);
	}

	public function contains($haystick, $needle): bool {
		return sys_contains($haystick, $needle);
	}

}