<?php declare(strict_types=1);


namespace sgs\core\library;

// handles encryption, decryption of strings
class sgsKey {

	private string $seedKey;

	public function __construct(string $seedKey) {
        $this->seedKey=sha1($seedKey);
    }
	
	public function decrypted(string $text): string {
		$txt = $this->sys_keyED(base64_decode($text),$this->seedKey);
		$tmp = "";
		for ($i=0;$i<strlen($txt);$i++){
			$md5 = substr($txt,$i,1);
			$i++;
			$tmp.= (substr($txt,$i,1) ^ $md5);
		}
		return $tmp;
	}

	public function encrypted(string $text): string {
		srand((double)microtime()*1000000);
		$encrypt_key = md5(rand(0,32000));
		$ctr=0;
		$tmp = "";
		for ($i=0;$i<strlen($text);$i++) {
			if ($ctr==strlen($encrypt_key)) $ctr=0;
			$tmp.= substr($encrypt_key,$ctr,1) . (substr($txt,$i,1) ^ substr($encrypt_key,$ctr,1));
			$ctr++;
		}
		return base64_encode($this->sys_keyED($tmp,$this->seedKey));
	}

	// Encryption by Ari Kuorikoski (ari.kuorikoski § finebyte.com)
	private function sys_keyED($txt,$encrypt_key): string {
		$encrypt_key = md5($encrypt_key);
		$ctr=0;
		$tmp = "";
		
		for ($i=0;$i<strlen($txt);$i++){
			if ($ctr==strlen($encrypt_key)) $ctr=0;
			$tmp.= substr($txt,$i,1) ^ substr($encrypt_key,$ctr,1);
			$ctr++;
		}
		
		return $tmp;
	}

}