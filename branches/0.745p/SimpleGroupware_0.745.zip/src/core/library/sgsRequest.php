<?php declare(strict_types=1);

/**
 * url request
 */

namespace sgs\core\library;
use sgs\core\library\request\query;
use sgs\core\library\request\query\{find};

class sgsRequest {	

	// TODO implement decent query factory
	protected const queryNamespace = 'sgs\\core\\library\\request\\query\\';


	public function defines(string $query): bool {
		return !empty($_REQUEST[$query]);
	}

	// query exists?
	public function __isset(string $query): bool {
		return isset($_REQUEST[$query]);
	}

	// remove
	public function __unset(string $query): void {
		unset($_REQUEST[$query]);
	}


	public function __set(string $query, $definition): void {
		$_REQUEST[$query] = $definition;
	}

	public function __get(string $query ): query {
		$newQuery = self::queryNamespace.$query;
		return new $newQuery($this);
	}

}