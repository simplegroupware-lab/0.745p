<?php declare(strict_types=1);

/**
 * 
 */

namespace sgs\core\library;

use sgs\core\library\session\state\app as appState;
use sgs\core\library\request\query;
use sgs\core\library\request\query\find;


class sgsSession {

	private sgsRequest $request;
	private appState $appState;

	public function __construct(sgsRequest $request) {
		$this->request = $request;
		$this->appState = new appState;
	}

	public function process () {

		// prepare query 'find=' (can have multiple 'find[]=')
		$this->request->find->process();	
		
		// prepare query 'fschema='
		$this->request->fschema->process();

		// prepare query 'folder2='
		$this->request->folder2->process();
		
		$this->appState->setOnNull(appState::treetype,'folders');
		$this->processFolderOnTreeTypeQuery();

		$this->appState->setOnNull(appState::treevisible,true);		
		$this->appState->setOnNull(appState::hidedata,false);
		
		$this->processFolderOnTreeQuery1();

		$this->processFolderOnHideDataQuery();
		$this->processFolderOnFolderQuery();
		
		$this->processFolderOnTreeQuery2();
		$this->processFolderOnTreeQuery3();

		$this->processFolderOnItemQuery();

	}


	// prepare query 'folder2='
	private function processFolderOnFolder2Query(sgsRequest $request) {
//		if (!is_null($this->request->folder2->value) and !empty($_REQUEST["view2"]) and empty($_REQUEST["folder"])) {
//			if (!isset($_REQUEST["folder"])) $_REQUEST["folder"] = $_REQUEST["folder2"];
//			if (!isset($_REQUEST["view"])) $_REQUEST["view"] = $_REQUEST["view2"];
//		}		
	}

	// prepare query 'treetype='
	private function processFolderOnTreeTypeQuery() {
		if ($this->request->defines(query::treetype)) {
			if (isset($this->request->onecategory)) unset($_REQUEST["onecategory"]);
			$_SESSION["treetype"] = $_REQUEST["treetype"];
		}
	}

	// prepare query 'tree='
	private function processFolderOnTreeQuery1() {

		if (isset($this->request->tree)) {
			if ($_REQUEST["tree"]=="minimize") $_SESSION["treevisible"] = false;
			if ($_REQUEST["tree"]=="maximize") $_SESSION["treevisible"] = true;
		}
	}

	// prepare query 'folder='
	private function processFolderOnFolderQuery() {

		if (isset($this->request->folder)) {
			$folders = folders_from_path($_REQUEST["folder"]);
			$_SESSION["folder"] = $folders[0];
			if (count($folders)>1) $_REQUEST["folders"] = $folders;
		}
	}

	// prepare query 'hidedata='
	private function processFolderOnHideDataQuery() {
		if ($this->request->defines(query::hidedata)) $_SESSION["hidedata"]=!$_SESSION["hidedata"];
	}

	// prepare query 'tree='
	private function processFolderOnTreeQuery2() {
		if (isset($_REQUEST["tree"]) and $_REQUEST["tree"]=="closeall") $_SESSION["folder_states"] = array();
	}

	// prepare query 'tree='
	private function processFolderOnTreeQuery3() {
		if (!empty($_REQUEST["view"]) and !empty($_SESSION["folder"])) $_SESSION["view"]["_".$_SESSION["folder"]] = $_REQUEST["view"];
	}

	// prepare query 'item='
	private function processFolderOnItemQuery() {
		if (!empty($_REQUEST["item"]) and count($_REQUEST["item"])==1 and isset($_REQUEST["item"][0]) and $_REQUEST["item"][0]==0) unset($_REQUEST["item"]);
	}
	
	public function appState(): appState {
		return $this->appState;
	}

}