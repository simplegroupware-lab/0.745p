<?php declare(strict_types=1);


namespace sgs\core\library;

// handles the config.php file
class sgsConfig {

	private sgsStore $store;
	private sgsDB $db;
	private sgsKey $key;

	public function __construct(sgsStore $store, string $version) {
		$this->store = $store;
		if (!defined('CORE_VERSION_config')) define('CORE_VERSION_config',$version);
	}

	// load definitions (from file), throws exception if wrong version
	public function load() {
		@include($this->store->directory().'/config.php');		
		if (!$this->isVersionOK()) throw new \Exception('wrong Version',1);
		if (!$this->versionExists()) throw new \Exception('no Version',2);

		$this->key = new sgsKey($seedKey = $this->adminUser());

		$this->db = new sgsDB(
				$type 		= SETUP_DB_TYPE,
				$host 		= SETUP_DB_HOST,
				$user 		= SETUP_DB_USER,
				$password 	= $this->key->decrypted(SETUP_DB_PW),
				$name 		= SETUP_DB_NAME
			);
	}
	
	// runs setup
	public function setup() {
		require('core/classes/setup.php');
		require('core/classes/validate.php');
		require('core/classes/sgsml_parser.php');
		require('core/classes/admin.php');
		require('core/classes/trigger.php');
		require('core/classes/modify.php');
		require('core/setup.php');
	}

	// backup file
	public function backup() {
		$dir = $this->store->directory();		
		$old = $dir.'/config_old.php';
		if (file_exists($old)) rename($old,$dir.'/config_'.time().'.php');
		rename($dir.'/config.php',$old);
		touch($old);
	}

	public function version(): string {
		return CORE_VERSION_config;
	}

	public function isForceSSL(): bool {
		return FORCE_SSL==1;
	}

	public function isCheckDOS(): bool {
		return CHECK_DOS==1;
	}

	public function isDebug(): bool {
		return DEBUG;
	}

	public function isSetupAuthNTLMSSO(): bool {
		return SETUP_AUTH_NTLM_SSO==1;
	}

	public function getSetupLanguage(): string {
		return SETUP_LANGUAGE;
	}

	private function isVersionOK(): bool {
		return (defined('CORE_VERSION') and $version=CORE_VERSION);
	}

	//region Database
	public function db(): sgsDB {
		return $this->db;
	}

	public function isDBConfigured(): bool {
		return $this->db->isConfigured();
	}

	public function adminUser(): string {
		return SETUP_ADMIN_USER;
	}

	// region private
	private function versionExists(): bool {
		return defined('CORE_VERSION');
	}

}