<?php declare(strict_types=1);

/**
 * abstraction for a template engine
 */

namespace sgs\core\library;

class sgsStore {
		
	public function __construct(string $directory) {
		if (!defined('SIMPLE_STORE')) define('SIMPLE_STORE',$directory);
	}
	
	public function directory(): string {
		return SIMPLE_STORE;
	}

}