<?php declare(strict_types=1);

namespace sgs\core\library\session\state;
use sgs\core\library\app\state\folders as foldersState;

class folders extends repository implements foldersState {


}