<?php declare(strict_types=1);

namespace sgs\core\library\session\state;

class repository {
	
//  public

	// returns null if empty
	public function __get(string $name) {
		return $this->get($name);
	}

	public function __set(string $name, $value): void {
		$this->set($name, $value);
	}

	public function __isset(string $name): bool {
		return $this->exists($name);
	}
	
	public function setOnNull(string $name, $value): void {
		if (!$this->exists($name)) $this->set($name, $value);
	}

	protected function exists(string $name): bool {
		return isset($_SESSION[$name]);
	}

//	protected

	protected function set(string $name, $value): void {
		$_SESSION[$name] = $value;
	}

	// returns null if empty
	protected function get(string $name) {
		if ($this->exists($name)) {
			return (empty($_SESSION[$name])? null : $_SESSION[$name]);
		} else return null;
	}

}