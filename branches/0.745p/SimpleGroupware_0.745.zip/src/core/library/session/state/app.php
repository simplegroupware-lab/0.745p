<?php declare(strict_types=1);

namespace sgs\core\library\session\state;
use sgs\core\library\app\state\{
	app as appState,
	folders as foldersState,
	view as viewState
};

class app extends repository implements appState {

	public function foldersState(): foldersState {
		return new folders;
	}

	public function viewState(): viewState {
		return new view;
	}
}