<?php
/**
 * Simple Groupware
 * http://www.simple-groupware.de
 * Copyright (C) 2002-2011 by Thomas Bley
 */

@set_time_limit(1800);
if (!ini_get('display_errors')) @ini_set('display_errors','1');

header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: private, max-age=1, must-revalidate");
header("Pragma: no-cache");
out_header();

//check PHP-Version
$phpversion = "5.2.0";
if (version_compare(PHP_VERSION, $phpversion, "<")) {
  out_exit(sprintf("Setup needs php with at least version %s ! (".PHP_VERSION.")",$phpversion),3);
}

//check Extensions
$extensions_sys = get_loaded_extensions();
foreach(array("pcre", "zlib") as $key => $val) {
  if (in_array($val, $extensions_sys)) continue;
  out_exit(sprintf("[0] Setup needs php-extension with name %s !", $val));
}

//check Memory
$memory_min = 4000000;
$memory_min_str = str_replace("000000","M",$memory_min);
$memory = ini_get("memory_limit");
if (!empty($memory)) {
  $memory_int = (int)str_replace("m","000000",strtolower($memory));
  if ($memory_int < $memory_min) out_exit(sprintf("[1] Please modify your php.ini or add an .htaccess file changing the setting '%s' to '%s' (current value is '%s') !", "memory_limit", $memory_min_str, $memory));
}

//check safe mode
$settings = array("safe_mode"=>0);
foreach($settings as $key => $val) {
  $setting = ini_get($key);
  if ($setting != $val) out_exit(sprintf("[2] Please modify your php.ini or add an .htaccess file changing the setting '%s' to '%s' (current value is '%s') !", $key, $val, $setting));
}

//clean up directory simple_cache
if (is_dir("./simple_cache/") and !is_dir("./simple_store/")) dirs_delete_all("./simple_cache/");


clearstatcache();
$exclude = array("sgs_installer.php","simple_store","build","README.txt","license.txt");


//check read, write folder permissions
if (!is_writable("./")) {
  $message = sprintf("[4] Please give write access to %s",realpath("./"));
  if (strpos(PHP_OS,"WIN")===false) {
	$message .= "<br>".sprintf("If file system permissions are ok, please check the configs of %s if present.", "SELinux, suPHP, Suhosin");
  }
  out_exit($message);
}



out();



// adjust access permissions to files and folders
$fileiterator = new RecursiveDirectoryIterator(".");
// Loop through files
foreach(new RecursiveIteratorIterator($fileiterator) as $file) {
	sys_chmod((string)$file);
}



out("<br/><a href='index.html'>C O N T I N U E</a><br/>");
out_footer();

//checks php-memory usage
if (function_exists("memory_get_usage") and function_exists("memory_get_peak_usage")) {
  out("<!-- ".memory_get_usage()." - ".memory_get_peak_usage()." -->");
}


function out($str="",$nl=true) {
  echo str_replace(array("{t"."}","{"."/t}"),array("",""),$str);
  if ($nl) echo "<br/>\n";
  flush();
  @ob_flush();
}

function out_exit($str) {
  out($str);
  out("<br/><a href='sgs_installer.php'>Relaunch Installer</a><br/>");
  out_footer();
  exit;
}

function out_header() {
  out("<html><head>
	<title>Simple Groupware Installer</title>
	<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
	<style>
	body, h2, img, div, table.data, a { background-color: #FFFFFF; color: #666666; font-size: 13px; font-family: Arial, Helvetica, Verdana, sans-serif; }
	a,input { color: #0000FF; }
	input { font-size: 11px; background-color: #F5F5F5; border: 1px solid #AAAAAA; height: 18px; vertical-align: middle; padding-left: 5px; padding-right: 5px;
			-moz-border-radius:10px; -webkit-border-radius:8px; border-radius:10px; }
	.checkbox, .radio { border: 0px; background-color: transparent; }
	.submit { color: #0000FF; background-color: #FFFFFF; width: 125px; font-weight: bold; }
	.border { border-bottom: 1px solid black; }
	.headline { letter-spacing: 2px; font-size: 18px; font-weight: bold; }
	form { margin: 0px; }
	</style></head>
	<body>
	<div class='border headline'>Simple Groupware Installer v8</div>
  ");
}
function out_footer() {
  out("<div style='border-top: 1px solid black; padding-top:2px;'>COPYRIGHT |
	   <a href='http://www.simple-groupware.de/cms/Main/Installation' target='_blank'>Installation manual</a> |
	   <a href='http://www.simple-groupware.de/cms/Main/Documentation' target='_blank'>Documentation</a> |
	   <a href='http://www.simple-groupware.de/cms/Main/FAQ' target='_blank'>FAQ</a>
	   </div></div></body></html>", false);
}

function sys_mkdir($dir) {
  $old_umask = @umask(0);
  $result = @mkdir($dir,0777,true);
  @umask($old_umask);
  return $result;
}

function sys_chmod($file_dir) {
  if (is_dir($file_dir)) $mode = 0777; else $mode = 0666;
  chmod($file_dir, $mode);
}

function dirs_delete_all($path,$olderthan=0,$remove=true) {
  $my_dir = opendir($path);
  while (($file=readdir($my_dir))) {
    if ($file!="." and $file!="..") {
	  if (is_dir($path."/".$file)) {
		dirs_delete_all($path."/".$file,$olderthan);
	  } else {
	    if (file_exists($path."/".$file) and filectime($path."/".$file)+$olderthan < time()) @unlink($path."/".$file);
  } } }
  closedir($my_dir);
  if ($remove) @rmdir($path);
}

