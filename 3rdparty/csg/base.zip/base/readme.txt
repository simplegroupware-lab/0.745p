Date: 2015-03-03
Contributed by: Patrick Pliessnig
Owner: Patrick Pliessnig

Usage:
-----------------------------------------------------------
please check the pdf documentation for instructions


Useful for:
-----------------------------------------------------------
easy php scripting for sgs
