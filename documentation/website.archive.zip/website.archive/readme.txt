
1) website.archive.zip
=======================================================================
- contains the entire orginal website backuped with httrack-3.48.19.exe
- httrack-3.48.19.exe (windows version)

- usage:
  1) downlad zip-file
  2) unzip
  3) install httrack.exe
  4) open Project Simple Groupware.whtt
  5) browse the website locally

2) notes
======================================================================
httrack.exe is scanned with virus total and found free of virus
rescan neverless before use