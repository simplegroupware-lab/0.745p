<?php
require_once dirname(__FILE__).'/Artichow.cfg.php';
require_once ARTICHOW.'/Pattern.class.php';
?>