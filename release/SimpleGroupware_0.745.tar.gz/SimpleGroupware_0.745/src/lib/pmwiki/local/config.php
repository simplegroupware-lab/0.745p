<?php
require_once('cookbook/wsplus.php'); 
?>