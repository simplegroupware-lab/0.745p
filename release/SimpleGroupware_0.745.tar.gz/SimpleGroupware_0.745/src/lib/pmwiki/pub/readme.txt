IMPORTANT:
----------

Simple Groupware does not use the pub folder.
To place additional CSS statements, please use "<sgs-dir>/ext/cms/styles.css".